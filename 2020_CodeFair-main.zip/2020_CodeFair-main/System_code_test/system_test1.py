from main import *

map = Map()

"""불나기전 함수"""



while():
    listen

    gkatn

    response


print(map.fire_place_num)